export type Book = {
  id: string;
  title: string;
  author: string;
  year: number;
  genre: string;
};

export const BOOKS: Book[] = [
  { id: "b1", title: "The Silent Archive", author: "Meera Rao", year: 2019, genre: "Mystery" },
  { id: "b2", title: "Paper Lanterns", author: "Jun Watanabe", year: 2012, genre: "Fiction" },
  { id: "b3", title: "Atlas of Small Things", author: "Elena Ruiz", year: 2021, genre: "Essays" },
  { id: "b4", title: "Ink and Iron", author: "Harold Finch", year: 1998, genre: "History" },
  { id: "b5", title: "The Ninth Orbit", author: "Priya Nair", year: 2023, genre: "Sci-Fi" },
  { id: "b6", title: "Salt Roads", author: "Amara Diallo", year: 2016, genre: "Travel" },
  { id: "b7", title: "Quiet Mathematics", author: "Tomas Berg", year: 2008, genre: "Science" },
  { id: "b8", title: "A House of Bells", author: "Iris Kwan", year: 2020, genre: "Fiction" },
  { id: "b9", title: "Field Notes on Rain", author: "Daniel Okafor", year: 2014, genre: "Nature" },
];