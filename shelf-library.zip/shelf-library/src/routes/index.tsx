import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { BookOpen, Check } from "lucide-react";
import { BOOKS, type Book } from "@/data/books";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const STORAGE_KEY = "library-sold-books";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Shelf — Library Management System" },
      {
        name: "description",
        content:
          "Browse the library catalogue, open any book and mark it done to record it as sold.",
      },
      { property: "og:title", content: "Shelf — Library Management System" },
      {
        property: "og:description",
        content: "Browse the catalogue and mark books as sold in one click.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [sold, setSold] = useState<string[]>([]);
  const [selected, setSelected] = useState<Book | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setSold(JSON.parse(raw));
    } catch {
      /* ignore */
    }
  }, []);

  const persist = (next: string[]) => {
    setSold(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };

  const markDone = (id: string) => {
    if (!sold.includes(id)) persist([...sold, id]);
    setSelected(null);
  };

  const isSold = (id: string) => sold.includes(id);

  return (
    <main className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-6 py-8">
          <BookOpen className="h-7 w-7 text-primary" />
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Shelf Library</h1>
            <p className="text-sm text-muted-foreground">
              Tap a book to open it, then press Done to mark it sold.
            </p>
          </div>
          <span className="ml-auto text-sm text-muted-foreground">
            {sold.length} / {BOOKS.length} sold
          </span>
        </div>
      </header>

      <section className="mx-auto grid max-w-5xl gap-4 px-6 py-10 sm:grid-cols-2 lg:grid-cols-3">
        {BOOKS.map((book) => (
          <button
            key={book.id}
            onClick={() => setSelected(book)}
            className="group rounded-xl border border-border bg-card p-5 text-left shadow-sm transition-all hover:-translate-y-0.5 hover:border-accent hover:shadow-md"
          >
            <div className="flex items-start justify-between gap-3">
              <h2 className="text-base font-semibold leading-snug">{book.title}</h2>
              {isSold(book.id) ? (
                <Badge className="shrink-0 bg-accent text-accent-foreground">Sold</Badge>
              ) : (
                <Badge variant="secondary" className="shrink-0">
                  Available
                </Badge>
              )}
            </div>
            <p className="mt-1 text-sm text-muted-foreground">{book.author}</p>
            <p className="mt-3 text-xs uppercase tracking-wide text-muted-foreground">
              {book.genre} · {book.year}
            </p>
          </button>
        ))}
      </section>

      <Dialog open={selected !== null} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent>
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle>{selected.title}</DialogTitle>
                <DialogDescription>
                  {selected.author} · {selected.genre} · {selected.year}
                </DialogDescription>
              </DialogHeader>

              {isSold(selected.id) ? (
                <p className="flex items-center gap-2 rounded-lg bg-secondary p-4 text-sm font-medium text-secondary-foreground">
                  <Check className="h-4 w-4" />
                  This book is sold.
                </p>
              ) : (
                <p className="text-sm text-muted-foreground">
                  This copy is still available. Mark it done once the sale is complete.
                </p>
              )}

              <DialogFooter>
                {isSold(selected.id) ? (
                  <Button variant="secondary" onClick={() => setSelected(null)}>
                    Close
                  </Button>
                ) : (
                  <Button onClick={() => markDone(selected.id)}>Done</Button>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </main>
  );
}
