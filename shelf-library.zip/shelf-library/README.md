# Shelf — Library Management System

A small library catalogue built with React 19, TanStack Start/Router, Vite and Tailwind CSS v4.

Click any book to open its details, press **Done** to mark it sold. Books already
marked stay flagged as **Sold** (saved in the browser's localStorage).

## Getting started (VS Code)

```bash
npm install      # or: bun install / pnpm install
npm run dev      # http://localhost:8080
```

## Scripts
- `npm run dev` — dev server with hot reload
- `npm run build` — production build
- `npm run preview` — preview the build
- `npm run lint` — lint

## Where to edit
- `src/routes/index.tsx` — the library page (grid + book dialog + done/sold logic)
- `src/data/books.ts` — the book catalogue
- `src/styles.css` — design tokens (colors, radius, theme)
- `src/components/ui/*` — shadcn/ui components
